@extends('layouts.home_page')

@section('welcome')
    <div class="container" style="margin-top: 20px">
        <div class="text-center">
            <h4 class="" style="letter-spacing: 15px;">
                <span><hr style="width: 395px;"></span>
                Watch and Credit The Rhino
                <span><hr style="width: 395px;"></span>
            </h4>
        </div>
    </div>
@endsection