<?php $__env->startSection('welcome'); ?>
    <?php if(Session::has('cart')): ?>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <ul class="list-group">
                    <?php $__currentLoopData = $donates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <span class="badge"><?php echo e($donate['qty']); ?></span>
                            <strong><?php echo e($donate['item']['title']); ?></strong>
                            <span class="label label-success"><?php echo e($donate['amount']); ?></span>
                            <div class="btn-group">
                                <button type="button" class="btn btn-primary btn-xs dropdown-toggle"
                                data-toggle="dropdown">Action<span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a href="">Reduce by 1</a></li>
                                    <li><a href="">Reduce All</a></li>
                                    <li></li>
                                </ul>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
               <strong>Total : <?php echo e($totalAmount); ?></strong>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
               <a href="<?php echo e(route('checkout')); ?>" type="button" class="btn btn-success">Checkout</a>
            </div>
        </div>
    <?php else: ?>
    <div class="row justify-content-center">
        <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
          <h2>No Item in Cart</h2>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>