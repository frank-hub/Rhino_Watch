<?php $__env->startSection('welcome'); ?>
    <div class="container" style="margin-top: 20px">
        <div class="text-center">
            <h4 class="" style="letter-spacing: 15px;">
                <span><hr style="width: 395px;"></span>
                Watch and Credit The Rhino
                <span><hr style="width: 395px;"></span>
            </h4>
        </div>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $donates->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donateChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <?php $__currentLoopData = $donateChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <img src="<?php echo e($donate->imagePath); ?>" alt="..." class="img-responsive">
                    <div class="caption">
                        <h3><?php echo e($donate->title); ?></h3>
                        <p class="description">
                            <?php echo e($donate->description); ?>

                        </p>
                        <div class="clearfix">
                            <div class="pull-left price">$ <?php echo e($donate->amount); ?></div>
                            <a href="<?php echo e(route('donate.addToCart',['id'=> $donate->id ])); ?>" class="btn btn-success pull-right" role="button">Add to Cart</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>